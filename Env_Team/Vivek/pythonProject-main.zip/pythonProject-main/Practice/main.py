import requests
import html

# response = requests.get(url="https://api.sunrise-sunset.org/json")
# response.raise_for_status()
# data = response.json()
# latitude = data["iss_position"]["latitude"]
# longitude = data["iss_position"]["longitude"]
# dtls = (latitude,longitude)
# print(data)
# print(dtls)

# LATITUDE = 52.636879
# LONGITUDE = -1.139759
#
# parm = {"lat": LATITUDE,
#         "lng": LONGITUDE}
#
# res = requests.get(url="https://api.sunrise-sunset.org/json",params=parm)
# res.raise_for_status()
# data = res.json()
# print(data)


resp = requests.get(url="https://opentdb.com/api.php?amount=10")
resp.raise_for_status()
data = html.unescape(resp.json())
print(data)