import tkinter

window = tkinter.Tk()
window.title("My First")
window.minsize(width=600,height=600)


window.mainloop()