def mult_two(a, b) -> float:
    # your code here

    return a*b


print("Example")
print(mult_two('helo', 2))

