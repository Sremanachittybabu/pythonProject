import re


def get_seeds(line_string):
    pattern = re.compile(r'\b\d+\b')
    x = pattern.findall(line)
    return (x)


with open('test.txt', 'r') as file:
    for index, line in enumerate(file):

        # First line in file will be seeds list. Get the seeds list by calling function
        if index == 0:
            seeds = get_seeds(line)
            seeds_list = [int(a) for a in seeds]
            print(seeds_list)

