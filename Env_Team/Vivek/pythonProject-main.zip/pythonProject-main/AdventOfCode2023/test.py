
card_details = [1] * 100
print(card_details)